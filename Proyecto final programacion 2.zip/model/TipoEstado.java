package model;

public enum TipoEstado {
    BORRADO,PUBLICADO,PAUSADO,CANCELADO,FINALIZADO

}
