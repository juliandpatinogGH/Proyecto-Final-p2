package model;

public class Zona {
    private String IdZona;
    private String NombreZona;
    private int Capacidad;
    private Double PrecioBase;
    private TipoZona tipoZona;

    public Zona(String idZona, String nombreZona, int capacidad, Double precioBase, TipoZona tipoZona) {
        IdZona = idZona;
        NombreZona = nombreZona;
        Capacidad = capacidad;
        PrecioBase = precioBase;
        this.tipoZona = tipoZona;
    }

    public String getIdZona() {
        return IdZona;
    }

    public void setIdZona(String idZona) {
        IdZona = idZona;
    }

    public String getNombreZona() {
        return NombreZona;
    }

    public void setNombreZona(String nombreZona) {
        NombreZona = nombreZona;
    }

    public int getCapacidad() {
        return Capacidad;
    }

    public void setCapacidad(int capacidad) {
        Capacidad = capacidad;
    }

    public Double getPrecioBase() {
        return PrecioBase;
    }

    public void setPrecioBase(Double precioBase) {
        PrecioBase = precioBase;
    }

    public TipoZona getTipoZona() {
        return tipoZona;
    }

    public void setTipoZona(TipoZona tipoZona) {
        this.tipoZona = tipoZona;
    }

    @Override
    public String toString() {
        return "Zona{" +
                "IdZona='" + IdZona + '\'' +
                ", NombreZona='" + NombreZona + '\'' +
                ", Capacidad=" + Capacidad +
                ", PrecioBase=" + PrecioBase +
                ", tipoZona=" + tipoZona +
                '}';
    }
}
