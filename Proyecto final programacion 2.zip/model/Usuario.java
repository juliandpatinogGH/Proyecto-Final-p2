package model;

public class Usuario{
   private String IdUsuario;
   private String NombreCompletoUsu;
   private String CorreoElectronico;
   private String NroTelefono;

    public Usuario(String idUsuario, String nombreCompletoUsu, String correoElectronico, String nroTelefono) {
        IdUsuario = idUsuario;
        NombreCompletoUsu = nombreCompletoUsu;
        CorreoElectronico = correoElectronico;
        NroTelefono = nroTelefono;
    }

    public String getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        IdUsuario = idUsuario;
    }

    public String getNombreCompletoUsu() {
        return NombreCompletoUsu;
    }

    public void setNombreCompletoUsu(String nombreCompletoUsu) {
        NombreCompletoUsu = nombreCompletoUsu;
    }

    public String getCorreoElectronico() {
        return CorreoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        CorreoElectronico = correoElectronico;
    }

    public String getNroTelefono() {
        return NroTelefono;
    }

    public void setNroTelefono(String nroTelefono) {
        NroTelefono = nroTelefono;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "IdUsuario='" + IdUsuario + '\'' +
                ", NombreCompletoUsu='" + NombreCompletoUsu + '\'' +
                ", CorreoElectronico='" + CorreoElectronico + '\'' +
                ", NroTelefono='" + NroTelefono + '\'' +
                '}';
    }
}
