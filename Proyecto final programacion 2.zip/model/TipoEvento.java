package model;

public enum TipoEvento {
    CONCIERTO,TEATRO,CONFERENCIAS
}
