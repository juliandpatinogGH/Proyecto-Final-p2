package model;

public class Asiento {
    private String IdAsiento;
    private String Fila;
    private int numero;

    public Asiento(String idAsiento, String fila, int numero) {
        IdAsiento = idAsiento;
        Fila = fila;
        this.numero = numero;
    }

    public String getIdAsiento() {
        return IdAsiento;
    }

    public void setIdAsiento(String idAsiento) {
        IdAsiento = idAsiento;
    }

    public String getFila() {
        return Fila;
    }

    public void setFila(String fila) {
        Fila = fila;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "Asiento{" +
                "IdAsiento='" + IdAsiento + '\'' +
                ", Fila='" + Fila + '\'' +
                ", numero=" + numero +
                '}';
    }
}
