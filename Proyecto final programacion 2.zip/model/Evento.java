package model;


import java.time.LocalDateTime;

public class Evento {
    private String IdEvento;
    private String NombreEvento;
    private String Categoria;
    private String descripcion;
    private String ciudad;
    private LocalDateTime fechahora;
    private TipoEstado tipoEstado;
    private TipoEvento tipoEvento;

    public Evento(String idEvento, String nombreEvento, String categoria, String descripcion, String ciudad, LocalDateTime fechahora, TipoEstado tipoEstado, TipoEvento tipoEvento) {
        IdEvento = idEvento;
        NombreEvento = nombreEvento;
        Categoria = categoria;
        this.descripcion = descripcion;
        this.ciudad = ciudad;
        this.fechahora = fechahora;
        this.tipoEstado = tipoEstado;
        this.tipoEvento = tipoEvento;
    }

    public String getIdEvento() {
        return IdEvento;
    }

    public void setIdEvento(String idEvento) {
        IdEvento = idEvento;
    }

    public String getNombreEvento() {
        return NombreEvento;
    }

    public void setNombreEvento(String nombreEvento) {
        NombreEvento = nombreEvento;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String categoria) {
        Categoria = categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public LocalDateTime getFechahora() {
        return fechahora;
    }

    public void setFechahora(LocalDateTime fechahora) {
        this.fechahora = fechahora;
    }

    public TipoEstado getTipoEstado() {
        return tipoEstado;
    }

    public void setTipoEstado(TipoEstado tipoEstado) {
        this.tipoEstado = tipoEstado;
    }

    public TipoEvento getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(TipoEvento tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    @Override
    public String toString() {
        return "Evento{" +
                "IdEvento='" + IdEvento + '\'' +
                ", NombreEvento='" + NombreEvento + '\'' +
                ", Categoria='" + Categoria + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", ciudad='" + ciudad + '\'' +
                ", fechahora=" + fechahora +
                ", tipoEstado=" + tipoEstado +
                ", tipoEvento=" + tipoEvento +
                '}';
    }
}
