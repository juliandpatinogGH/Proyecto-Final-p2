package model;

import java.time.LocalDate;

public class Incidencia {
private String IdIncidencia;
private String Descripcion;
private LocalDate Fecha;

    public Incidencia(String idIncidencia, String descripcion, LocalDate fecha) {
        IdIncidencia = idIncidencia;
        Descripcion = descripcion;
        Fecha = fecha;
    }
}

